from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def custom_message(request):
    return HttpResponse("""
        <html>
            <head><title>Custom Message</title></head>
            <body style="text-align: center; margin-top: 50px; font-family: Arial, sans-serif;">
                <h1>Rizal says Hello!</h1>
                <p>Welcome to my Django project. This page is part of my assignment!</p>
                <p><strong>Date:</strong> December 21, 2024</p>
            </body>
        </html>
    """)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', custom_message),  # Root URL displays custom message
]
