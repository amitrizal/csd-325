from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def custom_message(request):
    # HTML content for the response
    message = """
    <html>
        <head>
            <title>Custom Message</title>
        </head>
        <body style="text-align: center; font-family: Arial, sans-serif; margin-top: 50px;">
            <h1>Rizal says Hello!</h1>
            <p>Welcome to my Django project. This is a custom message as part of the assignment.</p>
            <p><strong>Today's Date:</strong> December 21, 2024</p>
        </body>
    </html>
    """
    return HttpResponse(message)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', custom_message),  # Root URL displays custom message
]
