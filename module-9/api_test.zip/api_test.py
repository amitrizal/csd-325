import requests
import json

# Function to format and print JSON objects
def jprint(obj):
    """Prints JSON object in a formatted way."""
    text = json.dumps(obj, sort_keys=True, indent=4)
    print(text)

# Test connection to Google
response = requests.get('http://www.google.com')
print("Google Status Code:", response.status_code)

# Fetch data from Open Notify API
response = requests.get("http://api.open-notify.org/astros.json")
print("Open Notify API Status Code:", response.status_code)

if response.status_code == 200:
    data = response.json()
    print("\nRaw Response:", data)  # Unformatted response
    print("\nFormatted Response:")
    jprint(data)
else:
    print(f"Failed to retrieve data. Status Code: {response.status_code}")
